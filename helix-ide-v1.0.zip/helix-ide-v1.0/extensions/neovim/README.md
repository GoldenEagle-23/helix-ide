# Neovim Extension for Helix

This directory contains placeholders for a Neovim plugin that integrates the Helix coding agent. Users can trigger commands to send code context and receive AI-generated diffs.
