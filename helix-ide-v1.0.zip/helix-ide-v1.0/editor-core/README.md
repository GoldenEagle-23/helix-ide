# Editor Core (Helix Fork Placeholder)

This directory is reserved for the Rust-based Helix editor core fork. It remains intentionally empty in this snapshot; the actual fork and upstream synchronization should live here.
