"""
Filesystem MCP

This package exposes helpers to read and write files directly from the host filesystem. It supports diff generation and patch application used by Helix's coding agent.
"""

import os


def read_file(path: str) -> str:
    """Read the contents of a file from the host filesystem."""
    with open(path, 'r', encoding='utf-8') as f:
        return f.read()


def write_file(path: str, content: str) -> None:
    """Write content to a file on the host filesystem, creating directories if necessary."""
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, 'w', encoding='utf-8') as f:
        f.write(content)
