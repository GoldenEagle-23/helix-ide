# Licensing

Helix is released under a dual licensing model:

- **Apache 2.0** for the open-source components, including the agent runtime, filesystem MCP and CLI.
- **Commercial license** for proprietary services such as the hosted AI gateway, team dashboards and compliance features.

See the LICENSE file for the open-source license text and contact Nebula Technological Innovation for commercial terms.
