# Architecture Overview

The Helix architecture is composed of the following layers:

1. **Editor Extensions** (VS Code, Neovim, Helix): thin clients that capture code context and interact with the agent via the CLI or HTTP API.
2. **Helix CLI / Server**: orchestrates agent workflows, handles model routing via the Model Fabric and communicates with MCP services.
3. **Model Fabric**: abstraction layer that selects and invokes the appropriate language models based on task requirements (latency, cost, context size, etc.).
4. **MCP Services**: provide access to external systems including GitHub (via a GitHub App), filesystem operations, build/CI systems and cloud deployment platforms.

This modular design allows you to plug in new models and services without modifying the core logic.
