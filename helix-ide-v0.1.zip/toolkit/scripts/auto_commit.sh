#!/usr/bin/env bash
echo COMMIT