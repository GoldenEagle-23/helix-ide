# Helix IDE v0.1 — Canonical Nebula Edition

This is the **canonical Helix IDE v0.1** for Nebula.

Includes:
- Helix fork-aligned editor core scaffold
- AI Copilot (MCP-first)
- Auto-patch + auto-commit
- GitHub MCP + Linear MCP wiring
