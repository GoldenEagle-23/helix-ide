# Helix IDE (Pre‑Alpha) + AI Coding Toolkit

This bundle bootstraps **Helix IDE (pre‑alpha)** with an **AI‑assisted coding toolkit** aligned to Nebula MCP patterns.
It is designed to be **runnable tonight**, extensible later.

## What's Included
- Helix IDE scaffold (editor core + config)
- AI Coding Toolkit (prompts, scripts, Makefile)
- MCP-ready structure (repo ingestion + agent wrappers)
- Ollama/Qwen defaults

## Quick Start
```bash
cd helix-ide
make up
make ingest
make ask q="Explain the architecture"
```
