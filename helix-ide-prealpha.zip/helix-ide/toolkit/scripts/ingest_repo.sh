#!/usr/bin/env bash
echo "Ingesting repo into vector store (placeholder)"
