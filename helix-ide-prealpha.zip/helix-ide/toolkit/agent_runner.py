# Minimal agent runner placeholder
print("Helix IDE Agent Runner initialized")