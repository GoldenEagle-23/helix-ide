# Helix Coding Agent V1 — Public Positioning

Helix Coding Agent V1 is a **free-by-default, enterprise-capable AI coding agent**
that works locally or with any major model provider.

Key Differentiators:
- Free local agent (Ollama)
- Multi-model routing
- IDE-agnostic
- MCP-native
- Open-core

Target users:
- Indie devs
- Startups
- Enterprises
