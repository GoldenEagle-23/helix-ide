# Helix Open-Core Licensing

## Open (Apache 2.0)
- Core agent runtime
- Filesystem MCP
- CLI

## Commercial (Nebula License)
- Cloud gateway
- Team dashboards
- Hosted PR agents
- Compliance & audit logs

Revenue:
- SaaS subscriptions
- Enterprise contracts
- Marketplace extensions
