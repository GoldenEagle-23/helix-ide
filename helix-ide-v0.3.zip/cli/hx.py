#!/usr/bin/env python3
import sys
cmd = sys.argv[1:]

if cmd[:2] == ["agent","run"]:
    print("Helix Agent running task:", " ".join(cmd[2:]))
else:
    print("hx agent run <task>")
