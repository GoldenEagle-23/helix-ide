# Filesystem MCP

Provides real-time repo access:
- Read/write files
- Diff generation
- No embedding step required
