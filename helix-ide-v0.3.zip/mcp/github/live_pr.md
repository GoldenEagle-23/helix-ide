# Live GitHub PR MCP

Capabilities:
- Create branch
- Push commits
- Open Pull Request
- Attach Linear issue
