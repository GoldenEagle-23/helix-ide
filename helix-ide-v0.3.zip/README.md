# Helix IDE v0.3 — Nebula Canonical

This release adds:
1. Live GitHub PR creation
2. Filesystem MCP (zero-ingest)
3. Helix CLI (`hx agent run`)
4. Public Helix Coding Agent V1 positioning
5. Open-core licensing & monetization split
